package com.example.tabtest;

import android.app.TabActivity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;

public class TabHostColor extends TabActivity implements OnTabChangeListener {
	TabHost tabHost;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        tabHost = getTabHost();
        
        
        
        
        LayoutInflater inflater = LayoutInflater.from(this);
		inflater.inflate(R.layout.activity_main, tabHost.getTabContentView(), true);

//		Drawable icon = getResources().getDrawable(R.drawable.ic_launcher);
//
//		tab.addTab(tab.newTabSpec("tag").setIndicator("tab1", icon)
//				.setContent(new Intent(this,Tab1.class)));
//		tab.addTab(tab.newTabSpec("tag").setIndicator("tab2", icon)
//				.setContent(new Intent(this,Tab2.class)));
//		tab.addTab(tab.newTabSpec("tag").setIndicator("tab3", icon)
//				.setContent(new Intent(this,Tab3.class)));
        
        
        
        
        
        
        
        
        
        
        
        
        
        tabHost.setOnTabChangedListener(this);
        
        tabHost.addTab(tabHost.newTabSpec("Tab01")
        		.setIndicator("First", getResources().getDrawable(R.drawable.ic_launcher))
        		.setContent(new Intent(this, TabFirst.class)));

        tabHost.addTab(tabHost.newTabSpec("Tab02")
        		.setIndicator("Second", getResources().getDrawable(R.drawable.ic_launcher))
        		.setContent(new Intent(this, TabSecond.class)));
        
        tabHost.addTab(tabHost.newTabSpec("Tab03")
        		.setIndicator("Third", getResources().getDrawable(R.drawable.ic_launcher))
        		.setContent(new Intent(this, TabThird.class)));
        
        // Tab�� �� ����
        for(int i = 0; i < tabHost.getTabWidget().getChildCount(); i++) {
        	tabHost.getTabWidget().getChildAt(i).setBackgroundColor(Color.parseColor("#7392B5"));
        }
        tabHost.getTabWidget().setCurrentTab(0);
        tabHost.getTabWidget().getChildAt(0).setBackgroundColor(Color.parseColor("#4E4E9C"));
    }

	@Override
	public void onTabChanged(String tabId) {
		// Tab �� ����
		for(int i = 0; i < tabHost.getTabWidget().getChildCount(); i++) {
        	tabHost.getTabWidget().getChildAt(i).setBackgroundColor(Color.parseColor("#7392B5"));
        } 
		tabHost.getTabWidget().getChildAt(tabHost.getCurrentTab()).setBackgroundColor(Color.parseColor("#4E4E9C"));
	}
}