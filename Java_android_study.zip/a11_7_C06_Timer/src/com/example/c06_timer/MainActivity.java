package com.example.c06_timer;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.TextView;

public class MainActivity extends Activity {
	int value=0;
    TextView mText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mText=(TextView)findViewById(R.id.text);
        mHandler.sendEmptyMessage(0);
}

Handler mHandler = new Handler() {
    public void handleMessage(Message msg) {
           value++;
          mText.setText("Value = " + value);
          mHandler.sendEmptyMessageDelayed(0,1000);
        }
   };
}

