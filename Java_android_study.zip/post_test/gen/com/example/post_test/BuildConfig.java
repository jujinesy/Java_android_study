/** Automatically generated file. DO NOT MODIFY */
package com.example.post_test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}