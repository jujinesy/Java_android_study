package wifi;

import com.james.SMSTesting.R;

import android.content.Intent;
import android.os.Handler;
import android.widget.ArrayAdapter;
import android.widget.Toast;

public class MsgHandler extends Handler {
	WifiActivity act;

	public MsgHandler() {

	}

	public MsgHandler(WifiActivity act) {
		this.act = act;
	}

	public void showMessage(final String msg) {
		act.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				Toast.makeText(act.getApplicationContext(), msg,
						Toast.LENGTH_SHORT).show();
			}
		});
	}

	public void handleMessage(android.os.Message msg) {
		switch (msg.what) {
		case MsgType.msgUnkown: {
			showMessage("�� �� ���� �޽��� ����");
		}
			break;
		case MsgType.msgConnectException: {
			showMessage("������ ã�� �� �����ϴ�");
		}
			break;

		case MsgType.msgConnectFail: {
			showMessage("���� ����");
			// UI to Connect
			act.runOnUiThread(new Runnable() {

				@Override
				public void run() {
					//act.setLayout(R.layout.layout_connect);
				}
			});

			// clear user list
			if (act.users != null) {
				act.users.clear();
				act.users.add("All");
				act.chatTargetAdapter = new ArrayAdapter<String>(
						act.getApplicationContext(),
						android.R.layout.simple_spinner_dropdown_item,
						act.users.toArray(new String[act.users.size()]));
				act.chatTarget.setAdapter(act.chatTargetAdapter);
			}
			// act.sct.stop();
			act.sc.keepRunning = false;
		}
			break;

		case MsgType.msgTest: {
			// UI to Login
			act.runOnUiThread(new Runnable() {

				@Override
				public void run() {
					act.serverIp.setEnabled(false);
					act.serverPort.setEnabled(false);
					act.btnConnect.setEnabled(false);
					act.loginId.setEnabled(true);
					act.loginPassword.setEnabled(true);
					act.btnLogin.setEnabled(true);
					act.btnSignup.setEnabled(true);
				}
			});

		}
			break;

		case MsgType.msgLoginOk: {
			showMessage("�α��� ����");
			// UI to Chat
			act.runOnUiThread(new Runnable() {

				@Override
				public void run() {
					act.setLayout(R.layout.layout_chat);
				}
			});
		}
			break;

		case MsgType.msgLoginFail: {
			showMessage("�α��� ����");
		}
			break;

		case MsgType.msgSignupOk: {
			showMessage("���� ����");
			// UI to Chat
			act.runOnUiThread(new Runnable() {

				@Override
				public void run() {
					act.setLayout(R.layout.layout_chat);
				}
			});
		}
			break;

		case MsgType.msgSignupFail: {
			showMessage("���� ����");
		}
			break;

		case MsgType.msgSendFail: {
			showMessage("���� ����");
		}
			break;

		case MsgType.msgNewUser: {
			String newUser = ((String) msg.obj);
			if (!newUser.equals(act.cd.username)) {
				act.users.add(newUser);
				act.chatTargetAdapter = new ArrayAdapter<String>(
						act.getApplicationContext(),
						android.R.layout.simple_spinner_dropdown_item,
						act.users.toArray(new String[act.users.size()]));
				act.chatTarget.setAdapter(act.chatTargetAdapter);
			}
		}
			break;

		case MsgType.msgSignout: {
			String outUser = (String) msg.obj;
			showMessage(outUser + " Bye!");

			act.users.clear();
			// act.sct.stop();
			act.sc.keepRunning = false;

		}
			break;

		case MsgType.msgSignoutToAll: {
			String outUser = (String) msg.obj;
			showMessage(outUser + "���� �������ϴ�");
			act.users.remove(outUser);
			act.chatTargetAdapter.remove(outUser);
		}
			break;

		case MsgType.msgString: {
			String message = (String) msg.obj;
			act.appendln(message);
		}
			break;
		case MsgType.msgFileChoose: {
			Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
			intent.setType("*/*");
			intent.addCategory(Intent.CATEGORY_OPENABLE);

			try {
				act.startActivityForResult(
						Intent.createChooser(intent, "Select a File to Upload"),
						WifiActivity.FILE_SELECT_CODE);
			} catch (android.content.ActivityNotFoundException ex) {
				// Potentially direct the user to the Market with a Dialog
				showMessage("���� �����ڸ� ��ġ�Ͻʽÿ�");
			}

		}
			break;

		case MsgType.msgFileTooLargeException: {
			showMessage("������ �ʹ� Ů�ϴ�");
		}
			break;

		case MsgType.msgDownloadComplete: {
			String filename = (String) msg.obj;
			showMessage(filename + "\n���� �ٿ�ε� ����");
		}
			break;
		case MsgType.msgDownloadConstructorException: {
			String filename = (String) msg.obj;
			showMessage(filename + "\n���� �ٿ�ε� �õ� ����");
		}
			break;
		case MsgType.msgDownloadRunException: {
			String filename = (String) msg.obj;
			showMessage(filename + "\n���� �ٿ�ε� �� ���� ");
		}
			break;
		case MsgType.msgDownloadDialog: {
			String str = (String) msg.obj;
			String filename = str.split("\n")[0];
			String target = str.split("\n")[1];
			act.DialogYN(filename,target);
		}
			break;
		case MsgType.msgDownloadRunAttempt: {
			String filename = (String) msg.obj;
			showMessage(filename + "\n���� �ٿ�ε� �õ�");
		}
			break;

		case MsgType.msgUploadComplete: {
			String filename = (String) msg.obj;
			showMessage(filename + "\n���� ���ε� ����");
		}
			break;
		case MsgType.msgUploadConstructorException: {
			String filename = (String) msg.obj;
			showMessage(filename + "\n���� ���ε� �õ� ����");
		}
			break;
		case MsgType.msgUploadRunException: {
			String filename = (String) msg.obj;
			showMessage(filename + "\n���� ���ε� �� ���� ");
		}
			break;
		case MsgType.msgUploadReject: {
			String str = (String) msg.obj;
			String rejecter = str.split("\n")[0];
			String filename = str.split("\n")[1];
			showMessage(rejecter + "�Բ��� \n" + filename + "\n�� �ޱ⸦ �ź��߽��ϴ�");
		}
			break;
		case MsgType.msgUploadRunAttempt: {
			String filename = (String) msg.obj;
			showMessage(filename + "\n���� ���ε� �õ�");
		}
			break;
		}
		super.handleMessage(msg);
	}

}
