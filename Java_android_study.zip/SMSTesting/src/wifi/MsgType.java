package wifi;

public final class MsgType {
	public static final int msgUnkown = 001;
	public static final int msgConnectFail = 101;
	public static final int msgConnectException = 102;
	public static final int msgTest = 110;
	public static final int msgLoginOk = 200;
	public static final int msgLoginFail = 201;
	public static final int msgSignupOk = 210;
	public static final int msgSignupFail = 211;
	public static final int msgSendFail = 301;

	public static final int msgNewUser = 1100;
	public static final int msgSignout = 1220;
	public static final int msgSignoutToAll = 1229;
	public static final int msgString = 1000;

	public static final int msgFileChoose = 500;
	public static final int msgFileTooLargeException = 501;

	public static final int msgDownloadComplete = 600;
	public static final int msgDownloadConstructorException = 602;
	public static final int msgDownloadRunException = 612;
	public static final int msgDownloadDialog = 690;
	public static final int msgDownloadRunAttempt = 699;

	public static final int msgUploadComplete = 700;
	public static final int msgUploadConstructorException = 702;
	public static final int msgUploadRunException = 712;
	public static final int msgUploadReject = 798;
	public static final int msgUploadRunAttempt = 799;

	public static final int objPathReturn = 3000;
	public static final int objDialogReturn = 3010;
}
