package wifi;

import android.os.Handler;



public class ClientData {
	public String serverAddr;
	public int port;
	public String username = "";
	public Handler handler;
	
	public ClientData(String addr, int port){
		this.serverAddr = addr;
		this.port =port;
	}
	public void setUserName(String username){
		this.username = username;
	}
	
	public void setHandler(Handler handler){
		this.handler = handler;
	}
}
