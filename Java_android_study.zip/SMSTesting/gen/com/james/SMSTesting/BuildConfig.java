/** Automatically generated file. DO NOT MODIFY */
package com.james.SMSTesting;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}