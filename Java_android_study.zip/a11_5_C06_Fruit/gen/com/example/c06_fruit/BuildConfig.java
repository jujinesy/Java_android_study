/** Automatically generated file. DO NOT MODIFY */
package com.example.c06_fruit;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}