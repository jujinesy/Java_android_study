package com.example.post_test2;

import java.net.URI;
import java.util.*;
import org.apache.http.*;
import org.apache.http.client.*;
import org.apache.http.client.entity.*;
import org.apache.http.client.methods.*;
import org.apache.http.client.utils.URIUtils;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.*;
import org.apache.http.message.*;
import org.apache.http.protocol.*;
import org.apache.http.util.*;
import android.app.*;
import android.os.*;
import android.util.*;
import android.view.*;
import android.widget.*;
/*
 * AndroidManifest.xml �� INTERNET �۹̼��� �����߳���?
 */
public class HttpClientDemo extends Activity {
 
 TextView tv;
 Button btnGet,btnPost,btnUpload,btnDownload;
 
 @Override 
 protected void onCreate(Bundle savedInstanceState) { 
  super.onCreate(savedInstanceState);
  setContentView(R.layout.activity_main); 
  tv = (TextView) findViewById(R.id.textView1);
  btnGet = (Button)findViewById(R.id.btnGet);
  btnPost = (Button)findViewById(R.id.btnPost);
  btnUpload = (Button)findViewById(R.id.btnUpload);
  btnDownload = (Button)findViewById(R.id.btnDownload);
 }
 
 private void httpRequestGet()throws Exception{
      HttpClient client = new DefaultHttpClient();
      //String url = "http://google.co.kr"; 
      String url = "http://192.168.1.164:8080/bbbb";
      HttpGet get = new HttpGet(url);
      HttpResponse response = client.execute(get);
      HttpEntity resEntity = response.getEntity();
      if(resEntity != null){
       String res = EntityUtils.toString(resEntity);
       tv.setText(res); 
      }
 }

 /* ���������� ���޵� �ѱ��� ������ ����.... */
 private void httpRequestGet_2()throws Exception {
  List<NameValuePair> qparams = new ArrayList<NameValuePair>();
  qparams.add(new BasicNameValuePair("q", "httpclient"));
  qparams.add(new BasicNameValuePair("name", "����ȣ"));
  qparams.add(new BasicNameValuePair("id", "jinhokim"));
  qparams.add(new BasicNameValuePair("oq", null));
  URI uri = URIUtils.createURI("http", "192.168.1.164", 8080, "/bbb", 
      URLEncodedUtils.format(qparams, "UTF-8"), null);
  HttpGet get = new HttpGet(uri);
  HttpClient client = new DefaultHttpClient();
     HttpResponse response = client.execute(get);
     HttpEntity resEntity = response.getEntity();
     if(resEntity != null){
      String res = EntityUtils.toString(resEntity); 
      tv.setText(res); 
     }
 }
 
 private void httpRequestPost() throws Exception { 
   HttpClient client = new DefaultHttpClient();
   /* ���߽ÿ��� ���ķ������� ȣ��Ʈ ��ǻ�� �ּҸ� ����ؾ� �Ѵ�.
    * localhost, 127.0.0.1 ���� ����� ��⿡�� ����Ǵ� �������� �ǹ��ϹǷ� �ȵ�
   */
      String postUrl = "http://192.168.1.164:8080/bbbb1";
      HttpPost post = new HttpPost(postUrl);
      List params  = new ArrayList();
      params.add(new BasicNameValuePair("name", "����ȣ"));
      params.add(new BasicNameValuePair("id", "jinhokim"));
      UrlEncodedFormEntity ent = new UrlEncodedFormEntity(params, HTTP.UTF_8);
      post.setEntity(ent);
      HttpResponse responsePost = client.execute(post);
      HttpEntity resEntity = responsePost.getEntity();
      if(resEntity != null){
       String res = EntityUtils.toString(resEntity);
       tv.setText(res);
      }
 }
 
 public void btnGet(View v){ 
  try{
   httpRequestGet_2(); 
  }catch(Exception e){}
 }
 public void btnPost(View v){ 
  try{
   httpRequestPost(); 
  }catch(Exception e){ Log.e("POST��û ����", e.getMessage()); }
 }
 public void btnUpload(View v){ 
  try{
   httpRequestGet(); 
  }catch(Exception e){}
 }
 public void btnDownload(View v){ 
  try{
   httpRequestGet(); 
  }catch(Exception e){}
 }
 
}
