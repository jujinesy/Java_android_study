/** Automatically generated file. DO NOT MODIFY */
package com.example.a11_3_c06_freeline;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}