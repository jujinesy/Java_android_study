package socket;

import ui.ChatFrame;
import java.io.*;
import java.net.*;
import java.util.Date;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

//서버와 통신을 위한 SocketClient 클래스다 기본적으로 스레스를 상속
public class SocketClient implements Runnable{
    
    //포트번호 히스토리값 다운로드 업로드를 위한 변수 선언
    public int port;
    public String serverAddr;
    public Socket socket;
    public ChatFrame ui;
    public ObjectInputStream In;
    public ObjectOutputStream Out;
    public History hist;
    
    //프레임을 받는 기본생성자이다
    public SocketClient(ChatFrame frame) throws IOException{
        // 포트
        ui = frame; this.serverAddr = ui.serverAddr; this.port = ui.port;
        //소켓
        socket = new Socket(InetAddress.getByName(serverAddr), port);
        //파일 스트림
        Out = new ObjectOutputStream(socket.getOutputStream());
        Out.flush();
        In = new ObjectInputStream(socket.getInputStream());
        
        //히스토리 내용을 전달한다.
        hist = ui.hist;
    }

    //스레드 시작부분이다
    @Override
    public void run() {
        boolean keepRunning = true;
        //스레드가 돌고있으면
        while(keepRunning){
            try {
                //들오는메 시지를 계속 읽는다
                Message msg = (Message) In.readObject();
                //디버깅을 위한 내용
                System.out.println("Incoming : "+msg.toString());
                
                //message 타입이지만 내가보낸 내용은 ME]를 붙인다.
                if(msg.type.equals("message")){
                    if(msg.recipient.equals(ui.username)){
                        ui.jTextArea1.append("["+msg.sender +" > Me] : " + msg.content + "\n");
                    }
                    else{
                        //아닌 경우 아이디를 붙여서 누가 말한지 확인해준다
                        ui.jTextArea1.append("["+ msg.sender +" > "+ msg.recipient +"] : " + msg.content + "\n");
                    }
                                        
                    //종료한 클라이언트가 있을경우
                    if(!msg.content.equals(".bye") && !msg.sender.equals(ui.username)){
                        String msgTime = (new Date()).toString();
                        
                        try{
                            //히스토리에 내용을 기록한다.
                            hist.addMessage(msg, msgTime);
                            //테이블 모델에도 기록하고 아이디는 Me라고 기록한다.
                            DefaultTableModel table = (DefaultTableModel) ui.historyFrame.jTable1.getModel();
                            table.addRow(new Object[]{msg.sender, msg.content, "Me", msgTime});
                        }
                        catch(Exception ex){}  
                    }
                }
                //로그인이 내용 메시지가 왔을경우
                else if(msg.type.equals("login")){
                    //서버에서 보내온내용이 트루이면
                    if(msg.content.equals("TRUE")){
                        //프레임의 로그인 가입 및 로그인 을 사용할수없게하고
                        //아래들을 활성화 시킨다
                        ui.jButton2.setEnabled(false); ui.jButton3.setEnabled(false);                        
                        ui.jButton6.setEnabled(true); ui.jButton7.setEnabled(true);
                        ui.jTextArea1.append("[SERVER > Me] : Login Successful\n");
                        ui.jTextField3.setEnabled(false); ui.jPasswordField1.setEnabled(false);
                        ui.jPasswordField1.setEnabled(false);
                        ui.skip();
                    }
                    else{
                        //flse가 서버에서 오면 로그인실패를 뿌려ㄷ준다
                        ui.jTextArea1.append("[SERVER > Me] : Login Failed\n");
                    }
                }
                //서버에 컨넥트가 됬을떄
                else if(msg.type.equals("test")){
                    //접속버튼을 사용할수 없게하고
                    ui.jButton1.setEnabled(false);
                    //로그인 가입 및 로그인을 활설화
                    ui.jButton2.setEnabled(true); ui.jButton3.setEnabled(true);
                    ui.jTextField3.setEnabled(true); ui.jPasswordField1.setEnabled(true);
                    ui.jTextField1.setEditable(false); ui.jTextField2.setEditable(false);
                }
                //새로운 유저가 추가되면 우측에 list를 업데이트한다.
                else if(msg.type.equals("newuser")){
                    if(!msg.content.equals(ui.username)){
                        boolean exists = false;
                        for(int i = 0; i < ui.model.getSize(); i++){
                            if(ui.model.getElementAt(i).equals(msg.content)){
                                exists = true; break;
                            }
                        }
                        //모델에 존재하지않는 사용자만 애드한다
                        if(!exists){ ui.model.addElement(msg.content); }
                    }
                }
                //회원가입 부분을 뜻한다.
                else if(msg.type.equals("signup")){
                    if(msg.content.equals("TRUE")){
                        ui.jButton2.setEnabled(false); ui.jButton3.setEnabled(false);
                        ui.jTextArea1.append("[SERVER > Me] : Singup Successful\n");
                    }
                    else{
                        ui.jTextArea1.append("[SERVER > Me] : Signup Failed\n");
                    }
                }
                //로그아웃부분을 뜻한다.
                else if(msg.type.equals("signout")){
                    //모든내용을 지우고 초기화 해준다.
                    if(msg.content.equals(ui.username)){
                        ui.jTextArea1.append("["+ msg.sender +" > Me] : Bye\n");
                        ui.jButton1.setEnabled(true); ui.jButton6.setEnabled(false); 
                        ui.jTextField1.setEditable(true); ui.jTextField2.setEditable(true);
                        
                        for(int i = 1; i < ui.model.size(); i++){
                            ui.model.removeElementAt(i);
                        }
                        
                        ui.clientThread.stop();
                    }
                    else{
                        ui.model.removeElement(msg.content);
                        ui.jTextArea1.append("["+ msg.sender +" > All] : "+ msg.content +" has signed out\n");
                    }
                }
                //다운로드 를 할경우 내가 아래의 역활을 수행한다.
                else if(msg.type.equals("upload_req")){
                    
                    if(JOptionPane.showConfirmDialog(ui, ("Accept '"+msg.content+"' from "+msg.sender+" ?")) == 0){
                        
                        //저장 주소를 받아온다.
                        JFileChooser jf = new JFileChooser();
                        jf.setSelectedFile(new File(msg.content));
                        int returnVal = jf.showSaveDialog(ui);
                       
                        //saveto에 주소 저장된
                        String saveTo = jf.getSelectedFile().getPath();
                        if(saveTo != null && returnVal == JFileChooser.APPROVE_OPTION){
                            Download dwn = new Download(saveTo, ui);
                            Thread t = new Thread(dwn);
                            t.start();
                            //send(new Message("upload_res", (""+InetAddress.getLocalHost().getHostAddress()), (""+dwn.port), msg.sender));
                            send(new Message("upload_res", ui.username, (""+dwn.port), msg.sender));
                        }
                        else{
                            send(new Message("upload_res", ui.username, "NO", msg.sender));
                        }
                    }
                    else{
                        send(new Message("upload_res", ui.username, "NO", msg.sender));
                    }
                }
                //업로드 요청을 받을경우
                else if(msg.type.equals("upload_res")){
                    //NO로 승인하지 않능는경우
                    if(!msg.content.equals("NO")){
                        int port  = Integer.parseInt(msg.content);
                        String addr = msg.sender;
                        
                        //ui.jButton7.setEnabled(false); ui.jButton6.setEnabled(false);
                        Upload upl = new Upload(addr, port, ui.file, ui);
                        Thread t = new Thread(upl);
                        t.start();
                    }
                    else{
                        ui.jTextArea1.append("[SERVER > Me] : "+msg.sender+" rejected file request\n");
                    }
                }
                else{
                    ui.jTextArea1.append("[SERVER > Me] : Unknown message type\n");
                }
            }
            //위내용들에 대한 예외처리다
            // 일단 스레드를 멈추고 경고내요을 텍스트아레아에 적는다
            catch(Exception ex) {
                keepRunning = false;
                ui.jTextArea1.append("[Application > Me] : Connection Failure\n");
                //ui.jButton1.setEnabled(true); ui.jTextField1.setEditable(true); ui.jTextField2.setEditable(true);
                //ui.jButton6.setEnabled(false); ui.jButton7.setEnabled(false); ui.jButton7.setEnabled(false);
                
                for(int i = 1; i < ui.model.size(); i++){
                    ui.model.removeElementAt(i);
                }
                
                ui.clientThread.stop();
                
                System.out.println("Exception SocketClient run()");
                ex.printStackTrace();
            }
        }
    }
    
    //사용자가 메시지를 보낼떄이다
    public void send(Message msg){
        try {
            //아웃풋 오브젝트에 메시지를 담아서
            Out.writeObject(msg);
            //보낼수 있게 플래쉬해준다.
            Out.flush();
            System.out.println("Outgoing : "+msg.toString());
            
            //message와 .bye가아닐경우
            if(msg.type.equals("message") && !msg.content.equals(".bye")){
                String msgTime = (new Date()).toString();
                try{
                    //위처럼 내용을 저장
                    hist.addMessage(msg, msgTime);               
                    DefaultTableModel table = (DefaultTableModel) ui.historyFrame.jTable1.getModel();
                    table.addRow(new Object[]{"Me", msg.content, msg.recipient, msgTime});
                }
                catch(Exception ex){}
            }
        } 
        catch (IOException ex) {
            System.out.println("Exception SocketClient send()");
        }
    }
    
    //스레드를 닫는 함수다.
    public void closeThread(Thread t){
        t = null;
    }
}
