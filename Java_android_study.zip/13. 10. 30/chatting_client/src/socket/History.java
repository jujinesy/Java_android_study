package socket;

import static socket.History.getTagValue;
import java.io.*;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;
import ui.HistoryFrame;
import javax.swing.table.DefaultTableModel;

//대화내용 저장을위한 history 클래스
public class History {
    
    //대화내용이 저장될 위치를 담고있다.
    public String filePath;
    
    //생성자겸 기본적으로 패스를 설정해준다.
    public History(String filePath){
        this.filePath = filePath;
    }
    
    //내가 보낸 메시지가 있거나 받은 메시지가 있을경우 실행된다.
    public void addMessage(Message msg, String time){
        
        try {
            //생성자로 생성된 주소로 초기화된다.
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filePath);
 
            Node data = doc.getFirstChild();
            
            //메시지를 받을때마다 xml 요소를 계속 생성하면서 내용을 기록한다.
            Element message = doc.createElement("message");
            Element _sender = doc.createElement("sender"); _sender.setTextContent(msg.sender);
            Element _content = doc.createElement("content"); _content.setTextContent(msg.content);
            Element _recipient = doc.createElement("recipient"); _recipient.setTextContent(msg.recipient);
            Element _time = doc.createElement("time"); _time.setTextContent(time);
            
            //이부분이 저장하는 부분이다.
            message.appendChild(_sender); message.appendChild(_content); message.appendChild(_recipient); message.appendChild(_time);
            data.appendChild(message);
            
            //내용을 저장하고 파일을 닫는부분이다.
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filePath));
            transformer.transform(source, result);
 
	   } 
           catch(Exception ex){
		System.out.println("Exceptionmodify xml");
	   }
	}
   
    //테이블 프레임에 내용을 담는함수다
    public void FillTable(HistoryFrame frame){
        
        //모델을 선언하고 테이블에 모델을 구해온다.
        DefaultTableModel model = (DefaultTableModel) frame.jTable1.getModel();
        
        try{
            //파일 패스를통해서 xml파일정보를불러온다.
            File fXmlFile = new File(filePath);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile);
            doc.getDocumentElement().normalize();
            //message내용을 기준으로 리스트를 만든다
            NodeList nList = doc.getElementsByTagName("message");
            
            //메시지 길이대로 사용자가 볼수 있도록 모든 메시지를 반복해서 출력해준다.
            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    model.addRow(new Object[]{getTagValue("sender", eElement), getTagValue("content", eElement), getTagValue("recipient", eElement), getTagValue("time", eElement)});
                }
            }
        }
        catch(Exception ex){
            System.out.println("Filling Exception");
        }
    }
    
    // 히스토리 함수중 FillTable에 쓰이는 함수다 element를받고 String 반환하는 캐스팅
    public static String getTagValue(String sTag, Element eElement) {
	NodeList nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();
        Node nValue = (Node) nlList.item(0);
	return nValue.getNodeValue();
  }
}
