package socket;

import ui.ChatFrame;
import java.io.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;

// 다운로드를 담당하는 클래스 이때, 스레드를 상속한다
public class Download implements Runnable{
    
    //서버 소켓과 소켓등 통신에 필요한 변수 선언
    public ServerSocket server;
    public Socket socket;
    public int port;
    public String saveTo = "";
    public InputStream In;
    public FileOutputStream Out;
    public ChatFrame ui;
    
    //생성자. 이때 다운로드위치와 채팅창 프랭임을 받는다
    public Download(String saveTo, ChatFrame ui){
        try {
            // 스레드 사용을 위해 서버소켓 및 포트번호를 설정해 준다 .
            server = new ServerSocket(0);
            port = server.getLocalPort();
            this.saveTo = saveTo;
            this.ui = ui;
        } 
        catch (IOException ex) {
            System.out.println("Exception [Download : Download(...)]");
        }
    }

    //스레드 부분으로 이벤트가발생하면 파일을 전부 다운받을때까지 반복된다.
    @Override
    public void run() {
        try {
            //소켓을 생성한다.
            socket = server.accept();
            System.out.println("Download : "+socket.getRemoteSocketAddress());
            
            //받을 스트림을 생성한다.
            In = socket.getInputStream();
            Out = new FileOutputStream(saveTo);
            
            //1024 단위로 계속 파일을 받는다
            byte[] buffer = new byte[1024];
            int count;
            
            //파일의 끝을 만날떄까지 다운 받는다
            while((count = In.read(buffer)) >= 0){
                Out.write(buffer, 0, count);
            }
            
            Out.flush();
            
            //사용자의 화면에 완료됬다는 내용을 표시해 준다.
            ui.jTextArea1.append("[Application > Me] : Download complete\n");
            
            //운이 끝나고 모든 객체를 닫는다.
            if(Out != null){ Out.close(); }
            if(In != null){ In.close(); }
            if(socket != null){ socket.close(); }
        } 
        catch (Exception ex) {
            System.out.println("Exception [Download : run(...)]");
        }
    }
}