package socket;

import java.io.Serializable;

//Serializable을 상속하는 메시지 규약
public class Message implements Serializable{
    
    //서버와 통신을하기위한 메시지 규약이다
    private static final long serialVersionUID = 1L;
    public String type, sender, content, recipient;
    
    //type sender content recipient 생성자
    public Message(String type, String sender, String content, String recipient){
        this.type = type; this.sender = sender; this.content = content; this.recipient = recipient;
    }
    
    //총 4가지 인자값을 저장되며 type sender content recipient 다
    @Override
    public String toString(){
        return "{type='"+type+"', sender='"+sender+"', content='"+content+"', recipient='"+recipient+"'}";
    }
}
