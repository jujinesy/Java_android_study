package socket;

import java.io.*;
import java.net.*;

//서버 스레드 클래스 를 스레드를 상속받는다
class ServerThread extends Thread { 
	
    //서버소켓 소켓등 여러가지 변수선언
    public SocketServer server = null;
    public Socket socket = null;
    public int ID = -1;
    public String username = "";
    public ObjectInputStream streamIn  =  null;
    public ObjectOutputStream streamOut = null;
    public ServerFrame ui;

    //기본 생성자 받은 내용을 위 변수에 대입
    public ServerThread(SocketServer _server, Socket _socket){  
    	super();
        server = _server;
        socket = _socket;
        ID     = socket.getPort();
        ui = _server.ui;
    }
    
    //메시지를 보내는 함수이다.
    public void send(Message msg){
        try {
            streamOut.writeObject(msg);
            streamOut.flush();
        } 
        catch (IOException ex) {
            System.out.println("Exception [SocketClient : send(...)]");
        }
    }
    
    //ID를 얻는 함수
    public int getID(){  
	    return ID;
    }
   
    //스레드가 생성되면서 접속하는 ID마다 스레드가 생성되게 한다.
    @SuppressWarnings("deprecation")
	public void run(){  
    	ui.jTextArea1.append("\nServer Thread " + ID + " running.");
        while (true){  
    	    try{  
                Message msg = (Message) streamIn.readObject();
    	    	server.handle(ID, msg);
            }
            catch(Exception ioe){  
            	System.out.println(ID + " ERROR reading: " + ioe.getMessage());
                server.remove(ID);
                stop();
            }
        }
    }
    
    //스레드를 오픈하고 플래시하는 함수이다.
    public void open() throws IOException {  
        streamOut = new ObjectOutputStream(socket.getOutputStream());
        streamOut.flush();
        streamIn = new ObjectInputStream(socket.getInputStream());
    }
    
    //스레드를 닫는 함수 전부다 반환한다.
    public void close() throws IOException {  
    	if (socket != null)    socket.close();
        if (streamIn != null)  streamIn.close();
        if (streamOut != null) streamOut.close();
    }
}


//스레드와 비슷한ㄷ runnable를 상속하여 클래스 생성
public class SocketServer implements Runnable{
    //각종 변수를 선안한다
    public ServerThread clients[];
    public ServerSocket server = null;
    public Thread       thread = null;
    public int clientCount = 0, port;
    public ServerFrame ui;
    public Database db;

    //소켓서버 생성자. 이때 프래임을 받아서 저장ㅎ나다.
    public SocketServer(ServerFrame frame){
       
        clients = new ServerThread[50];
        ui = frame;
        //ui패스에 맏게 디비도생성
        db = new Database(ui.filePath);
        
	try{  
            //사용자가 설정한 포트로 서버를연다
	    server = new ServerSocket(port);
            //port = server.getLocalPort();
	    //서버 아이피와 포트를 추력하면서 서버가 돌고있다고 말한다.
            ui.jTextArea1.append("Server startet. IP : " + InetAddress.getLocalHost() + ", Port : " + server.getLocalPort());
            //스레드를 돌려 진짜 서버를 돌린다
	    start(); 
        }
	catch(IOException ioe){  
            ui.jTextArea1.append("Can not bind to port : " + port + "\nRetrying"); 
            //ui.RetryStart(0);
	}
    }
    
    //위와 같은 생성자이지만 포트를 추가로 더 받는다
    public SocketServer(ServerFrame frame, int Port){
       
        clients = new ServerThread[50];
        ui = frame;
        port = Port;
        db = new Database(ui.filePath);
        
	try{  
            //포트를 사용자로 받고 스레드를 돌린다.
	    server = new ServerSocket(port);
            port = server.getLocalPort();
	    ui.jTextArea1.append("Server startet. IP : " + InetAddress.getLocalHost() + ", Port : " + server.getLocalPort());
	    start(); 
        }
	catch(IOException ioe){  
            ui.jTextArea1.append("\nCan not bind to port " + port + ": " + ioe.getMessage()); 
	}
    }
	
    //클라이언트 접속을 계쏙 기다리는 스레드이다.
    public void run(){  
	while (thread != null){  
            try{  
		ui.jTextArea1.append("\nWaiting for a client ..."); 
	        addThread(server.accept()); 
	    }
	    catch(Exception ioe){ 
                ui.jTextArea1.append("\nServer accept error: \n");
                //ui.RetryStart(0);
	    }
        }
    }
	
    //스레드 스타트함수다
    public void start(){  
    	if (thread == null){  
            thread = new Thread( (Runnable) this); 
	    thread.start();
	}
    }
    
    //스레드를 멈추는 함수다.
    @SuppressWarnings("deprecation")
    public void stop(){  
        if (thread != null){  
            thread.stop(); 
	    thread = null;
	}
    }
    
    //접속한 클라이언트 ID에 대한 숫자를구하는함수
    private int findClient(int ID){  
    	for (int i = 0; i < clientCount; i++){
        	if (clients[i].getID() == ID){
                    return i;
                }
	}
	return -1;
    }
	
    //각종 클라이언트에서 온내용으들 다루는 부분이다.
    public synchronized void handle(int ID, Message msg){  
        //클라이언트가 나가면
	if (msg.content.equals(".bye")){
            //모든사용자에게 알리고 서버는 Id를 삭제한다.
            Announce("signout", "SERVER", msg.sender);
            remove(ID); 
	}
	else{
            //클라이언트로그인일경우
            if(msg.type.equals("login")){
                if(findUserThread(msg.sender) == null){
                    //디비에서 확인해서 있으면
                    if(db.checkLogin(msg.sender, msg.content)){
                        clients[findClient(ID)].username = msg.sender;
                        //클라이언트 객체로 트루라고일린다
                        clients[findClient(ID)].send(new Message("login", "SERVER", "TRUE", msg.sender));
                        //모든사용자에게 알린다
                        Announce("newuser", "SERVER", msg.sender);
                        SendUserList(msg.sender);
                    }
                    else{
                        //해당 아이디로 없다고 보낸다
                        clients[findClient(ID)].send(new Message("login", "SERVER", "FALSE", msg.sender));
                    } 
                }
                else{
                    //유저스레드가 없어도 실패
                    clients[findClient(ID)].send(new Message("login", "SERVER", "FALSE", msg.sender));
                }
            }
            //일반메시지일경우
            else if(msg.type.equals("message")){
                if(msg.recipient.equals("All")){
                    //모든사람들에게 알린다
                    Announce("message", msg.sender, msg.content);
                }
                else{
                    findUserThread(msg.recipient).send(new Message(msg.type, msg.sender, msg.content, msg.recipient));
                    clients[findClient(ID)].send(new Message(msg.type, msg.sender, msg.content, msg.recipient));
                }
            }
            //접속일경우 ok라고 서버에게 알린다.
            else if(msg.type.equals("test")){
                clients[findClient(ID)].send(new Message("test", "SERVER", "OK", msg.sender));
            }
            //사인업 메시지가 오면
            else if(msg.type.equals("signup")){
                if(findUserThread(msg.sender) == null){
                    //디비에서 있는지 확인하고
                    if(!db.userExists(msg.sender)){
                        //회원가입하고
                        db.addUser(msg.sender, msg.content);
                        clients[findClient(ID)].username = msg.sender;
                        clients[findClient(ID)].send(new Message("signup", "SERVER", "TRUE", msg.sender));
                        clients[findClient(ID)].send(new Message("login", "SERVER", "TRUE", msg.sender));
                        //모든사용자에게 새로운유저를 일린다.
                        Announce("newuser", "SERVER", msg.sender);
                        SendUserList(msg.sender);
                    }
                    else{
                        //없을경우 false 반환
                        clients[findClient(ID)].send(new Message("signup", "SERVER", "FALSE", msg.sender));
                    }
                }
                else{
                    //없을경우 false 반환
                    clients[findClient(ID)].send(new Message("signup", "SERVER", "FALSE", msg.sender));
                }
            }
            //업로드 요청을 받을경우 
            else if(msg.type.equals("upload_req")){
                //모든사요자에게 못보내도록 막는다
                if(msg.recipient.equals("All")){
                    clients[findClient(ID)].send(new Message("message", "SERVER", "Uploading to 'All' forbidden", msg.sender));
                }
                else{
                    //그런일이아니라면 해당유저로 내용을 전달
                    findUserThread(msg.recipient).send(new Message("upload_req", msg.sender, msg.content, msg.recipient));
                }
            }
            //업로드 요청을 받을경우
            else if(msg.type.equals("upload_res")){
                //해당사용자가 노가 아니면 업로드를 받는다.
                if(!msg.content.equals("NO")){
                    String IP = findUserThread(msg.sender).socket.getInetAddress().getHostAddress();
                    findUserThread(msg.recipient).send(new Message("upload_res", IP, msg.content, msg.recipient));
                }
                else{
                    findUserThread(msg.recipient).send(new Message("upload_res", msg.sender, msg.content, msg.recipient));
                }
            }
	}
    }
    
    //모든사요자에들에게 메시지를보내는함수
    public void Announce(String type, String sender, String content){
        Message msg = new Message(type, sender, content, "All");
        for(int i = 0; i < clientCount; i++){
            clients[i].send(msg);
        }
    }
    
    //새로운유저가 추가되었을때 전체아리는 서버 함수
    public void SendUserList(String toWhom){
        for(int i = 0; i < clientCount; i++){
            findUserThread(toWhom).send(new Message("newuser", "SERVER", clients[i].username, toWhom));
        }
    }
    
    //유저아이디로부터 스레드 번호ㄴ를찾는것
    public ServerThread findUserThread(String usr){
        for(int i = 0; i < clientCount; i++){
            if(clients[i].username.equals(usr)){
                return clients[i];
            }
        }
        return null;
    }
	
    //아이디를 가지고 스레드를 삭제하는 함수
    @SuppressWarnings("deprecation")
    public synchronized void remove(int ID){  
    int pos = findClient(ID);
        if (pos >= 0){  
            ServerThread toTerminate = clients[pos];
            ui.jTextArea1.append("\nRemoving client thread " + ID + " at " + pos);
	    if (pos < clientCount-1){
                for (int i = pos+1; i < clientCount; i++){
                    clients[i-1] = clients[i];
	        }
	    }
	    clientCount--;
	    try{  
	      	toTerminate.close(); 
	    }
	    catch(IOException ioe){  
	      	ui.jTextArea1.append("\nError closing thread: " + ioe); 
	    }
	    toTerminate.stop(); 
	}
    }
    
    //소켓번호로 스레드를 추가하는함수이다
    private void addThread(Socket socket){  
	if (clientCount < clients.length){  
            ui.jTextArea1.append("\nClient accepted: " + socket);
	    clients[clientCount] = new ServerThread(this, socket);
	    try{  
                //오픈하고 스타트해준다.
	      	clients[clientCount].open(); 
	        clients[clientCount].start();  
	        clientCount++; 
	    }
	    catch(IOException ioe){  
	      	ui.jTextArea1.append("\nError opening thread: " + ioe); 
	    } 
	}
	else{
            ui.jTextArea1.append("\nClient refused: maximum " + clients.length + " reached.");
	}
    }
}
