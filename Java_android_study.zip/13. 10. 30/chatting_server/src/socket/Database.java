package socket;

import static socket.Database.getTagValue;
import java.io.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

//데이타베이스 클래스
public class Database {
    
    //파일이 저장되어있는 곳을 저장하는 변수
    public String filePath;
    
    //파일 저장위치를 저장해주는 생성자
    public Database(String filePath){
        this.filePath = filePath;
    }
    
    //유저가 디비에 존재하는 지 확인하는 함수
    public boolean userExists(String username){
        
        try{
            //파일패스를 받고 위치를열어본다
            File fXmlFile = new File(filePath);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile);
            doc.getDocumentElement().normalize();
            
            //user로 nList를 만든다
            NodeList nList = doc.getElementsByTagName("user");
            
            //리스트의 끝을 만날때깢 ㅣ해당유저가 있는 지확인한다
            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    if(getTagValue("username", eElement).equals(username)){
                        //있을면 true출력
                        return true;
                    }
                }
            }
            //없으면 false
            return false;
        }
        catch(Exception ex){
            System.out.println("Database exception : userExists()");
            return false;
        }
    }
    
    //해당유조가 아이디와 패스워드로 로그인한지 체크한다.
    public boolean checkLogin(String username, String password){
        
        if(!userExists(username)){ return false; }
        
        try{
            //패스를가져와서 디비를 읽는다.
            File fXmlFile = new File(filePath);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile);
            doc.getDocumentElement().normalize();
            
            //위와 마찬가지로 nList로 전체갯수를 확인
            NodeList nList = doc.getElementsByTagName("user");
            
            // 아이디를 먼저찾고 패스워드와 일치하는 지 확인한다
            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    if(getTagValue("username", eElement).equals(username) && getTagValue("password", eElement).equals(password)){
                        //맞으면 트루
                        return true;
                    }
                }
            }
            //없으면 flase 출력
            System.out.println("Hippie");
            return false;
        }
        catch(Exception ex){
            System.out.println("Database exception : userExists()");
            return false;
        }
    }
    
    //사용자가 회원가입하면 애드를 해준다
    public void addUser(String username, String password){
        
        try {
            //위와 방식은같고 해당위치를 열어서
            
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filePath);
 
            Node data = doc.getFirstChild();
            
            //user username password를 저장한다
            Element newuser = doc.createElement("user");
            Element newusername = doc.createElement("username"); newusername.setTextContent(username);
            Element newpassword = doc.createElement("password"); newpassword.setTextContent(password);
            
            newuser.appendChild(newusername); newuser.appendChild(newpassword); data.appendChild(newuser);
            
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filePath));
            transformer.transform(source, result);
 
	   } 
           catch(Exception ex){
		System.out.println("Exceptionmodify xml");
	   }
	}
    
    //checkLogin가쓰는 캐스팅 함수이다 String 반환
    public static String getTagValue(String sTag, Element eElement) {
	NodeList nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();
        Node nValue = (Node) nlList.item(0);
	return nValue.getNodeValue();
  }
}
