package com.example.sms_post;



import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiManager.WifiLock;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.telephony.gsm.SmsManager;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



public class SMSTesting extends Activity {
    Button btnSendSMS;
    EditText txtPhoneNo;
    EditText txtMessage;
    BackThread bt;
    
    WifiLock wifiLock = null;
    WakeLock wakeLock = null;
    
    static TextView tv;
    
    public static void setText(String str) {
    	tv.setText(str);
    }

	public void changeToWakeMode() {

		if (wifiLock == null) {
			WifiManager wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);
			wifiLock = wifiManager.createWifiLock("wifilock");
			wifiLock.setReferenceCounted(true);
			wifiLock.acquire();
		}

		if (wakeLock == null) {
			PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
			wakeLock = powerManager.newWakeLock(
					PowerManager.SCREEN_DIM_WAKE_LOCK, "wakelock");
			wakeLock.acquire();
		}
	}

	@Override
	public void onStop() {

		if (wifiLock != null) {
			wifiLock.release();
			wifiLock = null;
		}

		if (wakeLock != null) {
			wakeLock.release();
			wakeLock = null;
		}

		super.onStop();
	}

    
 
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);        
 
        btnSendSMS = (Button) findViewById(R.id.btnSendSMS);
        txtPhoneNo = (EditText) findViewById(R.id.txtPhoneNo);
        txtMessage = (EditText) findViewById(R.id.txtMessage);
        
        tv = (TextView)findViewById(R.id.textView1);
        
        SmsReceiver.str = "a";
        Logger.d("DEBUG", "debug1");
        
		btnSendSMS.setOnClickListener(new View.OnClickListener() 
        {
            public void onClick(View v) 
            {                
                String phoneNo = txtPhoneNo.getText().toString();
                String message = txtMessage.getText().toString();                 
                if (phoneNo.length()>0 && message.length()>0)                
                    sendSMS(phoneNo, message);                
                else
                    Toast.makeText(getBaseContext(), 
                        "Please enter both phone number and message.", 
                        Toast.LENGTH_SHORT).show();
            }
        });        
        
		// Intent sendIntent = new Intent(Intent.ACTION_VIEW);
		// sendIntent.putExtra("sms_body", "Content of the SMS goes here...");
		// sendIntent.setType("vnd.android-dir/mms-sms");
		// startActivity(sendIntent);

		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		changeToWakeMode();
		
		bt = new BackThread(hd);
		bt.setDaemon(true);
		bt.start();
		Logger.d("DEBUG", "debug6");

	}

	Handler hd = new Handler() {
		public void handleMessage(Message msg) {
			if (msg.what == 0) {
				// text1.setText("" + msg.arg1);
			}
		}
	};

	class BackThread extends Thread {
		int m = 0;
		Handler hd;

		BackThread(Handler handler) {
			hd = handler;
		}

		public void run() {
			while (true) {
				// m++;
				// Message msg = Message.obtain(hd, 0, m, 0);
				// hd.sendMessage(msg);
				// try {
				// Thread.sleep(1000);
				// } catch (InterruptedException e) {
				// e.printStackTrace();
				// }

				String url = "http://172.16.101.82:8080/Alive1";
				HttpClient http = new DefaultHttpClient();
				try {
					// ������ ������ �Ķ���� ����
					ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
					nameValuePairs.add(new BasicNameValuePair("Alive", "1"));
					nameValuePairs.add(new BasicNameValuePair("text","�������ٶ󸶹�"));

					// ����ð��� 5�ʰ� ������ timeout ó���Ϸ��� �Ʒ� �ڵ��� Ŀ��Ʈ�� Ǯ�� �����Ѵ�.
					HttpParams params = http.getParams();
					HttpConnectionParams.setConnectionTimeout(params, 5000);
					HttpConnectionParams.setSoTimeout(params, 5000);

					// HTTP�� ���� ������ ��û�� �����Ѵ�.
					// ��û�� ���Ѱ���� responseHandler�� handleResponse()�޼��尡 ȣ��Ǿ�
					// ó���Ѵ�.
					// ������ ���޵Ǵ� �Ķ���Ͱ��� ���ڵ��ϱ����� UrlEncodedFormEntity() �޼��带 ����Ѵ�.
					HttpPost httpPost = new HttpPost(url);
					UrlEncodedFormEntity entityRequest = new UrlEncodedFormEntity(
							nameValuePairs, "utf-8");
					httpPost.setEntity(entityRequest);
					http.execute(httpPost);
					Thread.sleep(20000);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
    
    //---sends an SMS message to another device---
    private void sendSMS(String phoneNumber, String message)
    {        
        String SENT = "SMS_SENT";
        String DELIVERED = "SMS_DELIVERED";
        
        Logger.d("DEBUG", "debug2");
 
        PendingIntent sentPI = PendingIntent.getBroadcast(this, 0,
            new Intent(SENT), 0);
 
        PendingIntent deliveredPI = PendingIntent.getBroadcast(this, 0,
            new Intent(DELIVERED), 0);
 
        //---when the SMS has been sent---
        registerReceiver(new BroadcastReceiver(){
        	
            @Override
            public void onReceive(Context arg0, Intent arg1) {
                switch (getResultCode())
                {
                    case Activity.RESULT_OK:
                        Toast.makeText(getBaseContext(), "SMS sent", 
                                Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                        Toast.makeText(getBaseContext(), "Generic failure", 
                                Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_NO_SERVICE:
                        Toast.makeText(getBaseContext(), "No service", 
                                Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_NULL_PDU:
                        Toast.makeText(getBaseContext(), "Null PDU", 
                                Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_RADIO_OFF:
                        Toast.makeText(getBaseContext(), "Radio off", 
                                Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        }, new IntentFilter(SENT));
        
        Logger.d("DEBUG", "debug3");
 
        //---when the SMS has been delivered---
        registerReceiver(new BroadcastReceiver(){
            @Override
            public void onReceive(Context arg0, Intent arg1) {
                switch (getResultCode())
                {
                    case Activity.RESULT_OK:
                        Toast.makeText(getBaseContext(), "SMS delivered", 
                                Toast.LENGTH_SHORT).show();
                        break;
                    case Activity.RESULT_CANCELED:
                        Toast.makeText(getBaseContext(), "SMS not delivered", 
                                Toast.LENGTH_SHORT).show();
                        break;                        
                }
            }
        }, new IntentFilter(DELIVERED)); 
        
        Logger.d("DEBUG", "debug3");
 
        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(phoneNumber, null, message, sentPI, deliveredPI);         
    }  
    
    
    
    
    
}






