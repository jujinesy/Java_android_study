package com.example.client;

import java.io.*;
import java.net.*;

import android.os.Handler;

//다운로드와  맞찬가지로 업로드 함수이다.
public class Upload implements Runnable {

	// 각종변수 선언
	public String addr;
	public int port;
	public Socket socket;
	public FileInputStream In;
	public OutputStream Out;
	public File file;
	public Handler handler;

	// 업로드 생선ㅇ자이다 주소 패스 프레임을 받아서 저장하고 업로드한다.
	public Upload(String addr, int port, File filepath, Handler handler) {
		this.handler = handler;
		try {
			file = filepath;
			socket = new Socket(InetAddress.getByName(addr), port);
			Out = socket.getOutputStream();
			In = new FileInputStream(filepath);

		} catch (Exception ex) {
			// System.out.println("Exception [Upload : Upload(...)]");
			ex.printStackTrace();
			android.os.Message MSG = handler.obtainMessage(
					MsgType.msgUploadConstructorException, (Object) file.getPath());
			handler.sendMessage(MSG);
		}
	}

	// 스레드 시작이다.
	@Override
	public void run() {
		try {
			byte[] buffer = new byte[1024];
			int count;
			android.os.Message MSG = handler.obtainMessage(
					MsgType.msgUploadRunAttempt, (Object) file.getPath());
			handler.sendMessage(MSG);

			while ((count = In.read(buffer)) >= 0) {
				Out.write(buffer, 0, count);
			}
			Out.flush();
			// 업로드 완료시 내용을 적어준다.
			MSG = handler.obtainMessage(
					MsgType.msgUploadComplete, (Object) file.getPath());
			handler.sendMessage(MSG);

		} catch (Exception ex) {
			// System.out.println("Exception [Upload : run()]");
			android.os.Message MSG = handler.obtainMessage(
					MsgType.msgUploadRunException, (Object) file.getPath());
			handler.sendMessage(MSG);
		} finally {
			// 업로드가 끝나면 객체를 닫아준다.
			if (In != null) {
				try {
					In.close();
				} catch (IOException e) {
				}
			}
			if (Out != null) {
				try {
					Out.close();
				} catch (IOException e) {
				}
			}
			if (socket != null) {
				try {
					socket.close();
				} catch (IOException e) {
				}
			}
		}
	}

}
