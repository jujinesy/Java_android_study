package com.example.client;

import com.Ryuji.android.BluetoothChat.R;

import android.content.Intent;
import android.os.Handler;
import android.widget.ArrayAdapter;
import android.widget.Toast;

public class MsgHandler extends Handler {
	WifiActivity act;

	public MsgHandler() {

	}

	public MsgHandler(WifiActivity act) {
		this.act = act;
	}

	public void showMessage(final String msg) {
		act.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				Toast.makeText(act.getApplicationContext(), msg,
						Toast.LENGTH_SHORT).show();
			}
		});
	}

	public void handleMessage(android.os.Message msg) {
		switch (msg.what) {
		case MsgType.msgUnkown: {
			showMessage("알 수 없는 메시지 수신");
		}
			break;
		case MsgType.msgConnectException: {
			showMessage("서버를 찾을 수 없습니다");
		}
			break;

		case MsgType.msgConnectFail: {
			showMessage("연결 실패");
			// UI to Connect
			act.runOnUiThread(new Runnable() {

				@Override
				public void run() {
					act.setLayout(R.layout.layout_connect);
				}
			});

			// clear user list
			if (act.users != null) {
				act.users.clear();
				act.users.add("All");
				act.chatTargetAdapter = new ArrayAdapter<String>(
						act.getApplicationContext(),
						android.R.layout.simple_spinner_dropdown_item,
						act.users.toArray(new String[act.users.size()]));
				act.chatTarget.setAdapter(act.chatTargetAdapter);
			}
			// act.sct.stop();
			act.sc.keepRunning = false;
		}
			break;

		case MsgType.msgTest: {
			// UI to Login
			act.runOnUiThread(new Runnable() {

				@Override
				public void run() {
					act.serverIp.setEnabled(false);
					act.serverPort.setEnabled(false);
					act.btnConnect.setEnabled(false);
					act.loginId.setEnabled(true);
					act.loginPassword.setEnabled(true);
					act.btnLogin.setEnabled(true);
					act.btnSignup.setEnabled(true);
				}
			});

		}
			break;

		case MsgType.msgLoginOk: {
			showMessage("로그인 성공");
			// UI to Chat
			act.runOnUiThread(new Runnable() {

				@Override
				public void run() {
					act.setLayout(R.layout.layout_chat);
				}
			});
		}
			break;

		case MsgType.msgLoginFail: {
			showMessage("로그인 실패");
		}
			break;

		case MsgType.msgSignupOk: {
			showMessage("가입 성공");
			// UI to Chat
			act.runOnUiThread(new Runnable() {

				@Override
				public void run() {
					act.setLayout(R.layout.layout_chat);
				}
			});
		}
			break;

		case MsgType.msgSignupFail: {
			showMessage("가입 실패");
		}
			break;

		case MsgType.msgSendFail: {
			showMessage("전송 실패");
		}
			break;

		case MsgType.msgNewUser: {
			String newUser = ((String) msg.obj);
			if (!newUser.equals(act.cd.username)) {
				act.users.add(newUser);
				act.chatTargetAdapter = new ArrayAdapter<String>(
						act.getApplicationContext(),
						android.R.layout.simple_spinner_dropdown_item,
						act.users.toArray(new String[act.users.size()]));
				act.chatTarget.setAdapter(act.chatTargetAdapter);
			}
		}
			break;

		case MsgType.msgSignout: {
			String outUser = (String) msg.obj;
			showMessage(outUser + " Bye!");

			act.users.clear();
			// act.sct.stop();
			act.sc.keepRunning = false;

		}
			break;

		case MsgType.msgSignoutToAll: {
			String outUser = (String) msg.obj;
			showMessage(outUser + "님이 나갔습니다");
			act.users.remove(outUser);
			act.chatTargetAdapter.remove(outUser);
		}
			break;

		case MsgType.msgString: {
			String message = (String) msg.obj;
			act.appendln(message);
		}
			break;
		case MsgType.msgFileChoose: {
			Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
			intent.setType("*/*");
			intent.addCategory(Intent.CATEGORY_OPENABLE);

			try {
				act.startActivityForResult(
						Intent.createChooser(intent, "Select a File to Upload"),
						WifiActivity.FILE_SELECT_CODE);
			} catch (android.content.ActivityNotFoundException ex) {
				// Potentially direct the user to the Market with a Dialog
				showMessage("파일 관리자를 설치하십시오");
			}

		}
			break;

		case MsgType.msgFileTooLargeException: {
			showMessage("파일이 너무 큽니다");
		}
			break;

		case MsgType.msgDownloadComplete: {
			String filename = (String) msg.obj;
			showMessage(filename + "\n파일 다운로드 성공");
		}
			break;
		case MsgType.msgDownloadConstructorException: {
			String filename = (String) msg.obj;
			showMessage(filename + "\n파일 다운로드 시도 실패");
		}
			break;
		case MsgType.msgDownloadRunException: {
			String filename = (String) msg.obj;
			showMessage(filename + "\n파일 다운로드 중 오류 ");
		}
			break;
		case MsgType.msgDownloadDialog: {
			String str = (String) msg.obj;
			String filename = str.split("\n")[0];
			String target = str.split("\n")[1];
			act.DialogYN(filename,target);
		}
			break;
		case MsgType.msgDownloadRunAttempt: {
			String filename = (String) msg.obj;
			showMessage(filename + "\n파일 다운로드 시도");
		}
			break;

		case MsgType.msgUploadComplete: {
			String filename = (String) msg.obj;
			showMessage(filename + "\n파일 업로드 성공");
		}
			break;
		case MsgType.msgUploadConstructorException: {
			String filename = (String) msg.obj;
			showMessage(filename + "\n파일 업로드 시도 실패");
		}
			break;
		case MsgType.msgUploadRunException: {
			String filename = (String) msg.obj;
			showMessage(filename + "\n파일 업로드 중 오류 ");
		}
			break;
		case MsgType.msgUploadReject: {
			String str = (String) msg.obj;
			String rejecter = str.split("\n")[0];
			String filename = str.split("\n")[1];
			showMessage(rejecter + "님께서 \n" + filename + "\n를 받기를 거부했습니다");
		}
			break;
		case MsgType.msgUploadRunAttempt: {
			String filename = (String) msg.obj;
			showMessage(filename + "\n파일 업로드 시도");
		}
			break;
		}
		super.handleMessage(msg);
	}

}
