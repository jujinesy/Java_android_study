package com.example.client;

import java.io.*;
import java.net.*;

import android.os.Handler;

// 다운로드를 담당하는 클래스 이때, 스레드를 상속한다
public class Download implements Runnable {

	// 서버 소켓과 소켓등 통신에 필요한 변수 선언
	public ServerSocket server;
	public Socket socket;
	public int port;
	public String saveTo = "";
	public InputStream In;
	public FileOutputStream Out;
	public Handler handler;

	// 생성자. 이때 다운로드위치와 채팅창 프랭임을 받는다
	public Download(String saveTo, Handler handler) {
		this.handler = handler;
		try {
			// 스레드 사용을 위해 서버소켓 및 포트번호를 설정해 준다 .
			port = 14185;
			server = new ServerSocket(port);
			this.saveTo = saveTo;

		} catch (IOException ex) {
			// "Exception [Download : Download(...)]"
			android.os.Message MSG = handler.obtainMessage(
					MsgType.msgDownloadConstructorException, (Object) saveTo);
			handler.sendMessage(MSG);
		}
	}

	// 스레드 부분으로 이벤트가발생하면 파일을 전부 다운받을때까지 반복된다.
	@Override
	public void run() {
		try {
			// 소켓을 생성한다.
//			System.out.println("Download : " +
//			 socket.getRemoteSocketAddress());
			socket = server.accept();
			 
			android.os.Message MSG = handler.obtainMessage(
					MsgType.msgDownloadRunAttempt, (Object) saveTo);
			handler.sendMessage(MSG);

			// 받을 스트림을 생성한다.
			In = socket.getInputStream();
			Out = new FileOutputStream(saveTo);

			// 1024 단위로 계속 파일을 받는다
			byte[] buffer = new byte[1024];
			int count;

			// 파일의 끝을 만날떄까지 다운 받는다
			while ((count = In.read(buffer)) >= 0) {
				Out.write(buffer, 0, count);
			}

			Out.flush();

			// 사용자의 화면에 완료됬다는 내용을 표시해 준다.
			MSG = handler.obtainMessage(
					MsgType.msgDownloadComplete, (Object) saveTo);
			handler.sendMessage(MSG);

		} catch (Exception ex) {
			// System.out.println("Exception [Download : run(...)]");
			android.os.Message MSG = handler.obtainMessage(
					MsgType.msgDownloadRunException, (Object) saveTo);
			handler.sendMessage(MSG);
			ex.printStackTrace();
		} finally {
			// 운이 끝나고 모든 객체를 닫는다.
			if (Out != null) {
				try {
					Out.close();
				} catch (IOException e) {
				}
			}
			if (In != null) {
				try {
					In.close();
				} catch (IOException e) {
				}
			}
			if (socket != null) {
				try {
					socket.close();
				} catch (IOException e) {
				}
			}
		}
	}
}
