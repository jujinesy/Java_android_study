package com.example.client;

import java.io.File;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.util.SortedSet;
import java.util.TreeSet;

import com.Ryuji.android.BluetoothChat.R;

import socket.Message;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.method.KeyListener;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class WifiActivity extends Activity {
	public static final int FILE_SELECT_CODE = 0;

	ClientData cd;
	SocketClient sc;
	Thread sct;

	// layout_connect
	EditText serverIp;
	EditText serverPort;
	Button btnConnect;

	EditText loginId;
	EditText loginPassword;
	Button btnLogin;
	Button btnSignup;

	// layout_chat
	Button btnSubmit;
	Button btnUpload;
	EditText chatInput;
	TextView chatWindow;
	ScrollView chatScroll;
	Spinner chatTarget;
	ArrayAdapter<String> chatTargetAdapter;
	SortedSet<String> users = new TreeSet<String>();
	Handler handler;

	public void setLayout(int layout) {
		switch (layout) {
		case R.layout.layout_connect: {
			setContentView(R.layout.layout_connect);

			serverIp = (EditText) findViewById(R.id.serverIp);
			serverPort = (EditText) findViewById(R.id.serverPort);
			btnConnect = (Button) findViewById(R.id.btnConnect);
			loginId = (EditText) findViewById(R.id.loginId);
			loginPassword = (EditText) findViewById(R.id.loginPassword);
			btnLogin = (Button) findViewById(R.id.btnLogin);
			btnSignup = (Button) findViewById(R.id.btnSignup);

			btnConnect.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					String ip = serverIp.getText().toString();
					String strPort = serverPort.getText().toString();
					if (ip.isEmpty()) {
						Toast.makeText(v.getContext(), "IP 입력",
								Toast.LENGTH_SHORT).show();
						return;
					}
					if (strPort.isEmpty()) {
						Toast.makeText(v.getContext(), "Port 입력",
								Toast.LENGTH_SHORT).show();
						return;
					}

					cd = new ClientData(ip, Integer.parseInt(strPort));
					sc = new SocketClient(cd, handler);
					sct = new Thread(sc);
					sct.start();
				}
			});

			btnLogin.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					String username = loginId.getText().toString();
					String password = loginPassword.getText().toString();

					if (username.isEmpty()) {
						Toast.makeText(v.getContext(), "ID 입력",
								Toast.LENGTH_SHORT).show();
						return;
					}
					if (password.isEmpty()) {
						Toast.makeText(v.getContext(), "Password 입력",
								Toast.LENGTH_SHORT).show();
						return;
					}

					cd.setUserName(username);
					sc.send(new Message("login", username, password, "SERVER"));
				}
			});

			btnSignup.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					String username = loginId.getText().toString();
					String password = loginPassword.getText().toString();

					if (username.isEmpty()) {
						Toast.makeText(v.getContext(), "ID 입력",
								Toast.LENGTH_SHORT).show();
						return;
					}
					if (password.isEmpty()) {
						Toast.makeText(v.getContext(), "Password 입력",
								Toast.LENGTH_SHORT).show();
						return;
					}

					cd.setUserName(username);
					sc.send(new Message("signup", username, password, "SERVER"));

				}
			});
		}
			break;

		case R.layout.layout_chat: {
			users.add("All");
			chatTargetAdapter = new ArrayAdapter<String>(
					getApplicationContext(),
					android.R.layout.simple_spinner_dropdown_item,
					users.toArray(new String[users.size()]));

			setContentView(R.layout.layout_chat);
			btnSubmit = (Button) findViewById(R.id.btnSubmit);
			btnUpload = (Button) findViewById(R.id.btnUpload);
			chatInput = (EditText) findViewById(R.id.chatInput);
			chatWindow = (TextView) findViewById(R.id.chatWindow);
			chatScroll = (ScrollView) findViewById(R.id.chatScroll);
			chatTarget = (Spinner) findViewById(R.id.chatTarget);
			chatTarget.setAdapter(chatTargetAdapter);

//			chatInput.setKeyListener(new KeyListener() {
//				
//				@Override
//				public boolean onKeyUp(View view, Editable text, int keyCode, KeyEvent event) {
//					// TODO Auto-generated method stub
//					return false;
//				}
//				
//				@Override
//				public boolean onKeyOther(View view, Editable text, KeyEvent event) {
//					// TODO Auto-generated method stub
//					return false;
//				}
//				
//				@Override
//				public boolean onKeyDown(View view, Editable text, int keyCode,
//						KeyEvent event) {
//					if (keyCode == KeyEvent.KEYCODE_ENTER){
//						submit();
//					}
//					return false;
//				}
//				
//				@Override
//				public int getInputType() {
//					// TODO Auto-generated method stub
//					return 0;
//				}
//				
//				@Override
//				public void clearMetaKeyState(View view, Editable content, int states) {
//					// TODO Auto-generated method stub
//					
//				}
//			});
			btnSubmit.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					submit();
				}
			});
			btnUpload.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// handler.sendEmptyMessage(MsgType.msgFileChoose);
					Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
					intent.setType("*/*");
					intent.addCategory(Intent.CATEGORY_OPENABLE);

					try {
						startActivityForResult(Intent.createChooser(intent,
								"Select a File to Upload"),
								WifiActivity.FILE_SELECT_CODE);
					} catch (android.content.ActivityNotFoundException ex) {
						// Potentially direct the user to the Market with a
						// Dialog
						System.out.println("파일 관리자를 설치하십시오");
					}
					// next logic onActivityResult
				}
			});

			if (getTarget().equals("All")) {
				btnUpload.setEnabled(false);
			}

			chatTarget.setOnItemSelectedListener(new OnItemSelectedListener() {

				@Override
				public void onItemSelected(AdapterView<?> arg0, View arg1,
						int arg2, long arg3) {
					// TODO Auto-generated method stub
					if (arg0.getItemAtPosition(arg2) == "All") {
						btnUpload.setEnabled(false);
					} else {
						btnUpload.setEnabled(true);
					}
				}

				@Override
				public void onNothingSelected(AdapterView<?> arg0) {
					// TODO Auto-generated method stub

				}
			});
//			chatScroll = (ScrollView)findViewById(R.id.chatScroll);
//			 chatScroll.post(new Runnable()
//			 {
//			 @Override
//			 public void run()
//			 {
//				 chatScroll.fullScroll(ScrollView.FOCUS_UP);
//
//			 }
//			 }); 
		}
			break;
		}

	}
	
	public void submit(){
		String msg = chatInput.getText().toString();
		String target = getTarget();

		if (!msg.isEmpty() && !target.isEmpty()) {
			chatInput.setText("");
			sc.send(new Message("message", cd.username, msg, target));
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setLayout(R.layout.layout_connect);

		handler = new MsgHandler(this);

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.login, menu);
		return true;
	}

	public void appendln(String text) {
		chatWindow.append(text + "\n");
	}

	@Override
	protected void onDestroy() {
		if (sc != null && sct != null) {
			try {
				sc.send(new Message("message", cd.username, ".bye", "SERVER"));
				// sct.stop();
				sc.keepRunning = false;
			} catch (Exception ex) {
			}
		}
		super.onDestroy();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch (requestCode) {
		case FILE_SELECT_CODE:
			if (resultCode == RESULT_OK) {
				// Get the Uri of the selected file
				Uri uri = data.getData();
				// Get the path
				String path = null;
				try {
					path = getPath(this, uri);
					if (path != null) {
						// from file upload
						sc.file = new File(path);
						long size = sc.file.length();
						if (size < 120 * 1024 * 1024) {
							sc.send(new Message("upload_req", cd.username,
									sc.file.getName(), getTarget()));
						} else {
							handler.sendEmptyMessage(MsgType.msgFileTooLargeException);
						}
					}
				} catch (URISyntaxException e) {
				}

				// android.os.Message MSG = android.os.Message.obtain(handler,
				// MsgType.objPathReturn, (Object) path);
				// handler.sendMessage(MSG);
				// Get the file instance
				// File file = new File(path);
				// Initiate the upload
			}
			break;
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	public static String getPath(Context context, Uri uri)
			throws URISyntaxException {
		if ("content".equalsIgnoreCase(uri.getScheme())) {
			String[] projection = { "_data" };
			Cursor cursor = null;

			try {
				cursor = context.getContentResolver().query(uri, projection,
						null, null, null);
				int column_index = cursor.getColumnIndexOrThrow("_data");
				if (cursor.moveToFirst()) {
					return cursor.getString(column_index);
				}
			} catch (Exception e) {
				// Eat it
			}
		} else if ("file".equalsIgnoreCase(uri.getScheme())) {
			return uri.getPath();
		}

		return null;
	}

	public void DialogYN(final String filename, final String target) {
		AlertDialog.Builder alt_bld = new AlertDialog.Builder(this);
		alt_bld.setMessage("Do you want get file '" + filename + "'?")
				.setCancelable(false)
				.setPositiveButton("Yes",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {
								// Action for 'Yes' Button
								String filepath = android.os.Environment
										.getExternalStoragePublicDirectory(
												android.os.Environment.DIRECTORY_DOWNLOADS)
										.getPath()
										+ "/" + filename;
								Download dwn = new Download(filepath, handler);
								Thread t = new Thread(dwn);
								t.start();
								sc.send(new Message("upload_res", ""
										+ cd.username, ("" + dwn.port), target));

								dialog.dismiss();
							}
						})
				.setNegativeButton("No", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						// Action for 'NO' Button
						sc.send(new Message("upload_res", cd.username, "NO",
								target));
						dialog.cancel();
					}
				});
		AlertDialog alert = alt_bld.create();
		alert.show();
	}

	public String getTarget() {
		String target = (String) chatTarget.getItemAtPosition(chatTarget
				.getSelectedItemPosition());
		return target;
	}
}
