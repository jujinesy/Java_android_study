package com.Ryuji.android.BluetoothChat;

import java.util.Set;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class main extends Activity implements OnClickListener  {
	
	Button connect_wifi;
	Button connect_bt;
	TextView wifi_status;
	TextView bt_status;
	boolean is3g = false;
	boolean isWifi = false;
	ConnectivityManager manager;
	BackThread mThread;
	BluetoothAdapter mBluetoothAdapter;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        Button connect_wifi = (Button) findViewById(R.id.wifi);
        Button connect_bt = (Button) findViewById(R.id.bt);
        
        this.wifi_status= (TextView)findViewById(R.id.TextView01);
        this.bt_status= (TextView)findViewById(R.id.TextView02);
        
        mThread = new BackThread(mHandler);
        mThread.setDaemon(true);
        mThread.start();

        manager = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        
       // 3G 를 사용하는지 확인힌다. 
//        is3g = manager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).isConnectedOrConnecting();
//       boolean is3g = false;
       
       // WIFI 를 사용하는지 확인한다.
//        isWifi = manager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).isConnectedOrConnecting();
//       boolean isWifi = false;
      
   	
       if(is3g){
           wifi_status.setText("in 3G");
	   }
	   else if(isWifi){
           wifi_status.setText("in WIFI");
	   }
	   else{
		  wifi_status.setText("not connected");
	   }
       
       mBluetoothAdapter = null;
       mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
       if(mBluetoothAdapter != null)
       {
           Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
           if (pairedDevices.size()!= 0)
           {
               // the device has paired devices
               for (BluetoothDevice device : pairedDevices)
               {
//                   Log.i(TAG, "device name: " + device.getName());
                   bt_status.setText("paired with\n"+device.getName());
               }
           }
           else
           {
               // no paired devices
//               Log.i(TAG, "no paired devices");
        	   bt_status.setText("not connected");
           }
       }
       connect_wifi.setOnClickListener(this);
       connect_bt.setOnClickListener(this);
 
    }

	@Override
	public void onClick(View v) {
		switch(v.getId()){
		case R.id.wifi:
			Intent intent1 = new Intent(getApplicationContext(), com.example.client.WifiActivity.class);
			startActivity(intent1);
			break;
		case R.id.bt :
			Intent intent2 = new Intent(getApplicationContext(), com.Ryuji.android.BluetoothChat.BluetoothChat.class);
			startActivity(intent2);
			break;
		}	
	}
	
    Handler mHandler = new Handler() {
    	
    	public void handleMessage(Message msg) {
                if (msg.what == 0) {
                	is3g = manager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).isConnectedOrConnecting();
                	isWifi = manager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).isConnectedOrConnecting();
                	
                if(is3g){
                         wifi_status.setText("in 3G");
              	   }
                else if(isWifi){
                    wifi_status.setText("in WIFI");
         	   }
         	   else{
         		  wifi_status.setText("not connected");
         	   }
               
               Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
                if (pairedDevices.size()!= 0)
                {
                    // the device has paired devices
                    for (BluetoothDevice device : pairedDevices)
                    {
//                        Log.i(TAG, "device name: " + device.getName());
                        bt_status.setText("paired with\n"+device.getName());
                    }
                }
                else
                {
             	   bt_status.setText("not connected");
                }
                
                }
        }
    };

    class BackThread extends Thread {
    	
        Handler mHandler;
        BackThread(Handler handler) {
                mHandler = handler;
        }
        public void run() {
                while (true) {
                        Message msg = new Message();
                        msg.what = 0;
                        mHandler.sendMessage(msg);
                        try { Thread.sleep(1000); } catch (InterruptedException e) {;}
                }
        }
	
	}
}