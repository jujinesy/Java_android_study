/** Automatically generated file. DO NOT MODIFY */
package com.example.a11_1_c06_handleevent;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}