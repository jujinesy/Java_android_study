/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;


import java.awt.AWTException;
import java.awt.MouseInfo;
import java.awt.PointerInfo;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
/**
 *
 * @author home1
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws AWTException {
        
        PointerInfo pi = MouseInfo.getPointerInfo();
        Robot rob = new Robot();
        
        
        
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        String copyString = "굿 ㅋㅋ";

     StringSelection contents = new StringSelection(copyString);
     clipboard.setContents(contents, null);



        
        
        
        
        
        
        
        
        
        
        rob.mouseMove(100, 500);
        rob.mousePress(InputEvent.BUTTON1_MASK);
        try {
        Thread.sleep(500);
        } catch (InterruptedException e) { }
        rob.mouseRelease(InputEvent.BUTTON1_MASK);
        rob.keyPress(KeyEvent.VK_CONTROL);
        rob.keyPress(KeyEvent.VK_V);
        try {
        Thread.sleep(500);
        } catch (InterruptedException e) { }
        rob.keyRelease(KeyEvent.VK_CONTROL);
        rob.keyRelease(KeyEvent.VK_V);
        

        
        rob.keyPress(KeyEvent.VK_ENTER);
        try {
        Thread.sleep(500);
        } catch (InterruptedException e) { }
        rob.keyRelease(KeyEvent.VK_ENTER);
        
        // TODO code application logic here
    }
}
