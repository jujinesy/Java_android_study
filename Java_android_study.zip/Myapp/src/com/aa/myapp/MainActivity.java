package com.aa.myapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements View.OnClickListener 
{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        Button btnApple=(Button)findViewById(R.id.button1);
		btnApple.setOnClickListener(this);
		btnApple=(Button)findViewById(R.id.button2);
		btnApple.setOnClickListener(this);
		btnApple=(Button)findViewById(R.id.button3);
		btnApple.setOnClickListener(this);
		btnApple=(Button)findViewById(R.id.button4);
		btnApple.setOnClickListener(this);
		btnApple=(Button)findViewById(R.id.button5);
		btnApple.setOnClickListener(this);

		


    }

    @Override
	public boolean onTouchEvent(MotionEvent event) {
            super.onTouchEvent(event);
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                   Toast.makeText(MainActivity.this,"Touch Event Received",
                           Toast.LENGTH_SHORT).show();
                   return true;
            }
            return false;
	}

	public void onClick(View v) {
		TextView textFruit=(TextView)findViewById(R.id.textView1);
		switch (v.getId()) {
		case R.id.button1:
			textFruit.setText("ù��° ��ư �̺�Ʈ~~~");
			break;
		case R.id.button2:
			textFruit.setText("�ٲ�ٴٴ�");
			break;
		case R.id.button3:
			textFruit.setText("���Ͼ���");
			break;
		case R.id.button4:
			textFruit.setText("���ϴ�");
			break;
		}		
	}


    

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}


//public boolean onTouchEvent(MotionEvent event) {
//    super.onTouchEvent(event);
//    if (event.getAction() == MotionEvent.ACTION_DOWN) {
//           Toast.makeText(C06_HandleEvent.this,"Touch Event Received",
//                   Toast.LENGTH_SHORT).show();
//           return true;
//    }
//    return false;
//}
